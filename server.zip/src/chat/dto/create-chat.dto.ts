export class CreateChatDto {}
